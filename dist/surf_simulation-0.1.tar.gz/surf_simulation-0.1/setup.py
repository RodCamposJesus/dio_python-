from setuptools import setup, find_packages

setup(
    name='surf_simulation',  # Nome do seu pacote
    version='0.1',           # Versão inicial
    author="Rodrigo Campos de Jesus",
    author_email="chocoliris@gmail.com",
    packages=find_packages(), # Encontra automaticamente os pacotes no projeto
)