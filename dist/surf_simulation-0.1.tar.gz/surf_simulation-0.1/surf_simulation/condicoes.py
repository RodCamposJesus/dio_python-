class Condicoes:
 def __init__(self, tamanho_onda):
  self.tamanho_onda = tamanho_onda

  def __str__(self):
   return f"Ondas de {self.tamanho_onda} pés."