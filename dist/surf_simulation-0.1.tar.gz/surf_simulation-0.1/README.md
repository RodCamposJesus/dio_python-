# surf_simulation
Programa simples simulando a escolha de pranchas de surf de
acodo com o tamanho das ondas.

## Installation 
pip install -e .
python -m surf_simulation.simulacao


## usage 
from surf_simulation.prancha import Prancha
from surf_simulation.condicoes import Condicoes
import condicoes