class Prancha:
    def __init__(self, tamanho):
        self.tamanho = tamanho

    def __str__(self):
        return f"Prancha de {self.tamanho} pés devido ao tamanho do mar."